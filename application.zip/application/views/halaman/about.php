<div class="content-wrapper">
    <div class="container">
		<div class="row aos-init aos-animate" data-aos="fade-up">
			<div class="col-sm-12 grid-margin">
				<div class="card">
					<div class="card-body">
						<center><h1>About Us</h1><center>
						<h5 class="font-weight-normal mt-4 mb-5">
                  Contact us : <br>
                  <b>Biro Kemahasiswaan dan Alumni (Career Development Center/CDC-Itenas)</b> <br>
                  Jl. PKH. Mustopha No.23 – Bandung 40124, Indonesia <br>
                  Phone : +62-22-7272215 (ext.235) <br>
                  Mobile : +62-812-8515-8712 <br>
                  e-Mail: cdc@itenas.ac.id or cdc.itenas@gmail.com
                  </h5>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>